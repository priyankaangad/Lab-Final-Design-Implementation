import pymysql
import os
import json
from datetime import datetime

# Fetch RDS details from environment variables
RDS_HOST = os.getenv('RDS_HOST')
RDS_USER = os.getenv('RDS_USER')
RDS_PASSWORD = os.getenv('RDS_PASSWORD')
RDS_DB_NAME = os.getenv('RDS_DB_NAME')

def connect_to_rds():
    try:
        connection = pymysql.connect(
            host=RDS_HOST,
            user=RDS_USER,
            password=RDS_PASSWORD,
            database=RDS_DB_NAME,
            cursorclass=pymysql.cursors.DictCursor
        )
        print("Connection to RDS succeeded.")
        return connection
    except Exception as e:
        print(f"ERROR: Unable to connect to RDS: {e}")
        raise e

def create_users_table(connection):
    try:
        with connection.cursor() as cursor:
            # Check if the table exists
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(255) NOT NULL UNIQUE,
                    email VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            connection.commit()
            print("Users table created or already exists.")
    except Exception as e:
        print(f"ERROR: Unable to create the users table: {e}")
        raise e

def lambda_handler(event, context):
    try:
        print(f"Received event: {json.dumps(event)}")

        # Determine the HTTP method
        http_method = event.get("httpMethod", "").upper()
        if http_method not in ["GET", "POST"]:
            return {
                'statusCode': 405,
                'body': json.dumps({'message': 'Method not allowed'})
            }

        # Connect to RDS
        connection = connect_to_rds()

        # Create the users table if it doesn't exist
        create_users_table(connection)

        if http_method == "POST":
            # Insert a new user
            body = json.loads(event.get("body", "{}"))
            username = body.get("username")
            email = body.get("email")

            if not username or not email:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': 'Username and email are required'})
                }

            with connection.cursor() as cursor:
                query = "INSERT INTO users (username, email) VALUES (%s, %s);"
                cursor.execute(query, (username, email))
                connection.commit()

            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'User created successfully'})
            }

        elif http_method == "GET":
            # Check for query parameters to list tables, describe a table, or list users
            query_params = event.get("queryStringParameters", {})
            list_tables = query_params.get("list_tables", "false").lower() == "true"
            list_users = query_params.get("list_users", "false").lower() == "true"
            describe_table = query_params.get("describe_table")

            with connection.cursor() as cursor:
                if list_tables:
                    # Fetch all tables
                    cursor.execute("SHOW TABLES;")
                    tables = cursor.fetchall()
                    print(f"Tables: {tables}")
                    return {
                        'statusCode': 200,
                        'body': json.dumps({'message': 'Tables retrieved successfully', 'tables': tables})
                    }

                elif describe_table:
                    # Describe a specific table
                    query = f"DESCRIBE {describe_table};"
                    print(f"Executing query: {query}")
                    cursor.execute(query)
                    table_description = cursor.fetchall()
                    print(f"Table Description: {table_description}")
                    return {
                        'statusCode': 200,
                        'body': json.dumps({'message': f'Description of table {describe_table}', 'table_description': table_description})
                    }

                elif list_users:
                    # Fetch all users
                    query = "SELECT id, username, email, created_at FROM users;"
                    cursor.execute(query)
                    users = cursor.fetchall()
                    print(f"Users: {users}")
                    return {
                        'statusCode': 200,
                        'body': json.dumps({'message': 'Users retrieved successfully', 'users': users})
                    }

                else:
                    return {
                        'statusCode': 400,
                        'body': json.dumps({'message': 'Invalid query parameter. Use list_tables=true, list_users=true, or describe_table=<table_name>.'})
                    }

    except pymysql.MySQLError as e:
        print(f"MySQL error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'MySQL error occurred', 'error': str(e)})
        }
    except Exception as e:
        print(f"ERROR: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal server error', 'error': str(e)})
        }
    finally:
        if 'connection' in locals() and connection.open:
            connection.close()
            print("RDS connection closed.")
